import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { ApiService } from 'src/app/core/services';
import { tap, finalize, catchError } from "rxjs/operators";
import { of } from "rxjs";
import { Router } from "@angular/router";
import { NgxSpinnerService } from "ngx-spinner";

@Component({
  selector: 'app-nav',
  templateUrl: './nav.component.html',
  styleUrls: ['./nav.component.css']
})
export class NavComponent implements OnInit {

  @Output() public sidenavToggle = new EventEmitter();

  menus: any;
  error: any;
  isLoading: boolean = false;
  
  constructor(
    private apiservice: ApiService,
    private router: Router,
    private spinner: NgxSpinnerService
  ) { }

  ngOnInit(){
    this.getMenu()
  }

  prduct(id){
    this.router.navigate([`product`, { id: id }]) 
  }

  // Get Menu

  getMenu(){
    this.spinner.show();
    this.apiservice.get('/api/catalog/category/list','')
    .pipe(
      tap(response => {
        this.menus = response.data;
      }),
      finalize(() => (this.spinner.hide())),
      catchError(error => of((
        this.error = error,console.log(error)
        
        )))
    )
    .subscribe();
  }


  
  public onToggleSidenav = () => {
    this.sidenavToggle.emit();
  }

}

