export * from './header/header.component';
export * from './footer/footer.component';
export * from './lets-work/lets-work.component';
export * from './latest-news/latest-news.component'