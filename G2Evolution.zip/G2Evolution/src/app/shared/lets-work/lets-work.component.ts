import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ApiService } from 'src/app/core/services';
import { tap, finalize, catchError } from 'rxjs/operators';
import { of } from 'rxjs';
import { NgxSpinnerService } from 'ngx-spinner';
import Swal from 'sweetalert2/dist/sweetalert2.js'

@Component({
  selector: 'app-lets-work',
  templateUrl: './lets-work.component.html',
  styleUrls: ['./lets-work.component.css']
})
export class LetsWorkComponent implements OnInit {

  enquiryForm : FormGroup;
  submitted: boolean = false;
  error: any;
  submit:boolean = true;
  loading:boolean = false;

  constructor(
    private formBuilder: FormBuilder,
    private enquiryService: ApiService,
    private spinner: NgxSpinnerService
  ) {
    this.enquiryForm = this.formBuilder.group({
      name: ["", Validators.required ],
      email: ["", [Validators.required, Validators.email]],
      // mobile: [null, [Validators.required,Validators.pattern('^((\\+91-?)|0)?[0-9]{10}$')]],
      message: ["", Validators.required ],
    })
  }

  get f() {
    return this.enquiryForm.controls;
  }

  enquiry(){
    this.submitted = true;
    if (this.enquiryForm.invalid) {
      console.log(this.enquiryForm.invalid);
      
      this.submit = true;
      this.loading = false;
     return;
   }
   else{
    this.submit = false;
    this.loading = true;
   }
   this.spinner.show();
    var Formelement = this.enquiryForm.value;
    this.enquiryService.post('/api/ask_demo_mail/send',Formelement).pipe(
      tap(response =>{
        Swal.fire('success', response.message, 'success');
      }),
      finalize(() => this.reset()),
      catchError(error => of(this.error = error, Swal.fire('error', error, 'error'),console.log(error)))
    ).subscribe();
   }

   reset(){
    this.spinner.hide(); this.submit = true;this.loading = false;
   }

  ngOnInit() {
  }

}
