import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ApiService } from 'src/app/core/services';
import { tap, finalize, catchError } from "rxjs/operators";
import { of } from "rxjs";
import { NgxSpinnerService } from "ngx-spinner";

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {
  isLoading: boolean;
  error: any;
  data: any;

  constructor(
    private ActivatedRoute: ActivatedRoute, 
    private apiservice: ApiService,
    private spinner: NgxSpinnerService
    ) {
    this.ActivatedRoute.params.subscribe((params) => {
      if (params["id"]) {
        /* Get Details of product Page */
        this.getProduct(params["id"])
      }
    })
  }

  getProduct(id){
    this.spinner.show();
    this.apiservice.post('/api/catalog/products/list',{category_id: id})
    .pipe(
      tap(response => {
        console.log(response);
        this.data = response[0];
      }),
      finalize(() => (this.spinner.hide())),
      catchError(error => of((
        this.error = error,console.log(error)
        
        )))
    )
    .subscribe();
  }

  ngOnInit() {
  }

  goContact(){
    alert('G2E')
  }

}
