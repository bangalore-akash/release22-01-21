import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ServicesRoutingModule } from './services-routing.module';
import { ServiceComponent } from './pages/service/service.component';
import { SharedModule } from 'src/app/shared/shared.module';

@NgModule({
  declarations: [ServiceComponent],
  imports: [
    CommonModule,
    ServicesRoutingModule,SharedModule
  ]
})
export class ServicesModule { }
