import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ApiService } from 'src/app/core/services';
import { tap, finalize, catchError } from 'rxjs/operators';
import { of } from 'rxjs';
import { NgxSpinnerService } from 'ngx-spinner';
import Swal from 'sweetalert2/dist/sweetalert2.js';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  enquiryForm : FormGroup;
  submitted: boolean = false;
  message: any;
  error: any;

  constructor(
   private router:Router,
   private formBuilder: FormBuilder,
   private enquiryService: ApiService,
   private spinner: NgxSpinnerService
  ) {
    this.enquiryForm = this.formBuilder.group({
      name: ["", Validators.required ],
      email: ["", [Validators.required, Validators.email]],
      subject: [""],
      mobile: [null, [Validators.required,Validators.pattern('^((\\+91-?)|0)?[0-9]{10}$')]],
      message: ["", Validators.required ],
    })
  }

  get f() {
    return this.enquiryForm.controls;
  }

  enquiry(){
    console.log(this.enquiryForm.value);
    
    this.submitted = true;
    if (this.enquiryForm.invalid) {
     return;
   }
   this.spinner.show();
    var Formelement = this.enquiryForm.value;
    this.enquiryService.post('/api/contact_mail/send',Formelement).pipe(
      tap(response =>{
        Swal.fire('success', response.message, 'success')
        this.message = response.message;
        if(response.status == "success" || response.status == "failure" ){
          
        }
      }),
      finalize(() => this.spinner.hide()),
      catchError(error => of(this.error = error, Swal.fire('error', 'Internal Server Error', 'error'),console.log(error)))
    ).subscribe();
   }

  ngOnInit() {
  }

  goContact(){
    this.router.navigate(['contact'])
  }

  upcomingCourses: any = {
    loop: true,
    mouseDrag: true,
    touchDrag: true,
    pullDrag: false,
    dots: false,
    navSpeed: 700,
    navText: [
      '<i class="fa fa-caret-left"></i>',
      '<i class="fa fa-caret-right"></i>'
    ],
    responsive: {
      0: {
        items: 1
      },
      400: {
        items: 2
      },
      740: {
        items: 2
      },
      940: {
        items: 2
      },
      1024: {
        items: 2
      }
    },
    nav: true
  };

}
