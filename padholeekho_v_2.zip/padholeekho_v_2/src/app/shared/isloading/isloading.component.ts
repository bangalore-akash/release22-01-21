import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-isloading',
  templateUrl: './isloading.component.html',
  styleUrls: ['./isloading.component.css']
})
export class IsloadingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
