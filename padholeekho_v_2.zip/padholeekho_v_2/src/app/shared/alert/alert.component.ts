import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-alert',
  templateUrl: './alert.component.html',
  styleUrls: ['./alert.component.css']
})
export class AlertComponent implements OnInit {
  _alertMsg: {
    "class": "",
    "text": "",
    "info": "",
    "colorClass": ""

  };

  alertValue: any;  // ----------Added new 

  @Input()
  set alertMsg(alertValue:any) {
    this._alertMsg = alertValue;
    setTimeout(() => {
      this.dismiss()
    }, 3000);
  }
  constructor() { }

  ngOnInit() {
  }

  dismiss() {
    this._alertMsg = this.alertValue ? this.alertValue: ""; // ----------Added new 
  }
}
