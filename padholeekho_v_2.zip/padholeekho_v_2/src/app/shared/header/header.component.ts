import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../core/services';
import { tap, catchError } from 'rxjs/operators';
import { of } from 'rxjs';
import { Router } from '@angular/router';

declare let $ : any;

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})

export class HeaderComponent implements OnInit {
  toggleValue: boolean = false;
  error: any;
  menudata = [];
  currentUrl: boolean = false;

  constructor(private apiservice: ApiService, private router: Router, ) { 
    $(document).ready(function () {
      $(document).click(function (event) { 
        var clickover = $(event.target);   
        var _opened = $(".exo-menu").hasClass("display");
        if (_opened === true && !clickover.hasClass("span-toggle")) { 
          $('.exo-menu').removeClass("display");
          $('.nav-toggle').removeClass("active");
        }
      });
    });



  }
  geturl(){
    if ( this.router.url == '/auth/test-series') {
      console.log('/auth/test-series');
      this.currentUrl = true
    } else {
      console.log('noooooooo');
    }
  }
  ngOnInit() {
    // Competitive Exam Menu 
    this.apiservice.get('/api/admin/course/level-setting/super-course/list', {status:'active'}).pipe(
      tap(response => {
        this.menudata = Array.from(Object.keys(response.data), k => response.data[k]);
      }),
      catchError(error => of(this.error = error))
    ).subscribe()
  }

  goDetailsPage(id) {
    this.router.navigate(['auth/competitive/cat', { id: id }]);
  }

  toggle() {
    this.toggleValue = !this.toggleValue ? true : false;
  }

}
