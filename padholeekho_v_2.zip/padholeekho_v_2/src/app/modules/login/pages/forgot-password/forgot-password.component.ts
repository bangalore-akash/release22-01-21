import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ForgotPasswordService } from '../../services';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { tap, finalize, catchError } from 'rxjs/operators';
import { of } from 'rxjs';



@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent implements  OnInit {

  resetForm: FormGroup;
  submitted: boolean = false;
  isLoading: boolean = false;
  error: any;
  message:any;

  constructor(
    private router: Router,
    private formBuilder: FormBuilder,
    private forgotpasswordservices: ForgotPasswordService
  ) {
    this.resetForm = this.formBuilder.group({
      emailphone:  [null, Validators.compose([Validators.required, Validators.pattern(/^(\d{10}|\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3}))$/)])],
    })
  }

  get f() { 
    return this.resetForm.controls; 
  }

  ngOnInit() {
  }

  reset(){
    this.submitted = true; 
    if (this.resetForm.invalid) {
      return;
    }
    this.isLoading = true;  
    this.forgotpasswordservices.forgotpasswordApi(this.resetForm.value).pipe(
      tap(response => { 
         this.message = response.response.message;
        if(response.status == 'success' && response.data.user_id){
          localStorage.setItem('user_Id', response.data.user_id); // Storing user id for password update
          this.router.navigate(['auth/OTP', { user_id: response.data.user_id, pageName: 'forgot' }]);
        }
      }),
      finalize(() => this.isLoading = false),
      catchError(error => of(this.error = error))
    ).subscribe();
  }

  goRegister() {
    this.router.navigate(['auth/register']);
  }


}
