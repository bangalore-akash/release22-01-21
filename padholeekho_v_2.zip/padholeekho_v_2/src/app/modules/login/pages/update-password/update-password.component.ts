import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { MustMatch } from 'src/app/shared';
import { Router } from '@angular/router';
import { UpdatePasswordService } from '../../services';
import { tap, finalize, catchError } from 'rxjs/operators';
import { of } from 'rxjs';

@Component({
  selector: 'app-update-password',
  templateUrl: './update-password.component.html',
  styleUrls: ['./update-password.component.css']
})
export class UpdatePasswordComponent implements OnInit {
  updatePasswordForm: FormGroup;
  submitted: boolean = false;
  isLoading: boolean = false;
  show_button: Boolean = false;
  show_eye: Boolean = false;
  message: any;
  error: any;

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private UpdatePasswordService: UpdatePasswordService
    ) {
    this.updatePasswordForm = this.formBuilder.group({
      password: ["", [Validators.required, Validators.minLength(6)]],
      confirmPassword: ['', Validators.required]
    }, { validator: MustMatch('password', 'confirmPassword') });
  }
  get f() { 
    return this.updatePasswordForm.controls; 
  }

  ngOnInit() {
  }
  showPassword() {
    this.show_button = !this.show_button;
    this.show_eye = !this.show_eye;
  }
  updatePassword(){
    this.submitted = true; 
    if (this.updatePasswordForm.invalid) {
      return;
    }
    let updatePasswordParams = {
      user_id: localStorage.getItem('user_Id'),
      password: this.updatePasswordForm.value.password,
    };
    this.isLoading = true;
    this.UpdatePasswordService.updatepasswordApi(updatePasswordParams).pipe(
      tap(response =>{
        this.message = response.response.message;
        if(response.status == 'success'){
          setTimeout(() => {
            this.router.navigate(['/auth/login'])
          }, 1000);
        }
      }),
      finalize(() => this.isLoading = false),
      catchError(error => of(this.error = error))
    ).subscribe();

  }

  goRegister(){
    this.router.navigate(['auth/register'])
  }

}
