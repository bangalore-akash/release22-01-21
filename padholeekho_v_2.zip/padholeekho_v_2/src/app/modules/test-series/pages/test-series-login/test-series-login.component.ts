import { Component, OnInit } from '@angular/core';
import { tap, finalize, catchError } from "rxjs/operators";
import { of} from "rxjs";
import {
  FormGroup,
  FormBuilder,
  Validators,
} from "@angular/forms";
import { Router } from "@angular/router";
import { LoginService } from 'src/app/modules/login/services';
import Swal from 'sweetalert2/dist/sweetalert2.js';

@Component({
  selector: 'app-test-series-login',
  templateUrl: './test-series-login.component.html',
  styleUrls: ['./test-series-login.component.css']
})
export class TestSeriesLoginComponent implements OnInit {

  loginForm: FormGroup;
  submitted: boolean = false;
  isLoading: boolean = false;
  error: any;
  errorMsg: any;
  message: any;
  alertMsg: { class: string; text: string; info: string };
  Toast = Swal.mixin({
    toast: true,
    position: 'bottom',
    showConfirmButton: false,
    timer: 7000,
    timerProgressBar: true,
    onOpen: (toast) => {
      toast.addEventListener('mouseenter', Swal.stopTimer)
      toast.addEventListener('mouseleave', Swal.resumeTimer)
    }
  })

  constructor(
    private loginService: LoginService,
    private formBuilder: FormBuilder,
    private router: Router
  ) {
    this.loginForm = this.formBuilder.group({
      emailphone: [
        null,
        Validators.compose([
          Validators.required,
          Validators.pattern(
            /^(\d{10}|\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3}))$/
          ),
        ]),
      ],
      password: ["", [Validators.required, Validators.minLength(6)]],
    });
  }

  get f() {
    return this.loginForm.controls;
  }

  ngOnInit() {}

  login() {
    this.submitted = true;
    if (this.loginForm.invalid) {
      return;
    }
    this.isLoading = true;
    this.loginService
      .loginApi(this.loginForm.value)
      .pipe(
        tap((response) => {
          this.message = response.response.message;
          if (response.status == "success") {
            localStorage.setItem("user_Id", response.data.user_id); // Storing user id for profile details
            this.router.navigate(["user/test-series/OnlineTestSeries"]);
          } else {
            this.Toast.fire({
              icon: 'success',
              title: response.response.message
            })
          }
        }),
        finalize(() => (this.isLoading = false)),
        catchError((error) => of(this.callError(error)))
      )
      .subscribe();
  }

  callError(error) {
    Swal.fire(error, 'success', 'success')
  }

  goRegister() {
    this.router.navigate(["auth/register"]);
  }
  forgetpassword() {
    this.router.navigate(["auth/login/forgetPassword"]);
  }

}
