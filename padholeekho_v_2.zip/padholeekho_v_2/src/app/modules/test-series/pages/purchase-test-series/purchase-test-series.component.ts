import { Component, OnInit } from "@angular/core";
import { tap, finalize, catchError } from "rxjs/operators";
import { of } from "rxjs";
import { Router } from "@angular/router";
import { ProfileService } from "src/app/modules/my-profile/services";

@Component({
  selector: "app-purchase-test-series",
  templateUrl: "./purchase-test-series.component.html",
  styleUrls: ["./purchase-test-series.component.css"],
})
export class PurchaseTestSeriesComponent implements OnInit {
  isLoading: boolean = false;
  error: any;
  userinfo: any;

  constructor(private profileServices: ProfileService, private router: Router) {
    this.userProfile();
  }

  ngOnInit() {}
  // User Profile

  userProfile() {
    let userId = localStorage.getItem("user_Id");
    this.isLoading = true;
    this.profileServices
      .myprofileApi(userId)
      .pipe(
        tap((response) => {
          this.userinfo = response.data;
        }),
        finalize(() => (this.isLoading = false)),
        catchError((error) => of((this.error = error)))
      )
      .subscribe();
  }
  changePassword() {
    this.router.navigate(["user/myProfile/changePassword"]);
  }
  updateProfile() {
    this.router.navigate(["user/myProfile/updateProfile"]);
  }
}
