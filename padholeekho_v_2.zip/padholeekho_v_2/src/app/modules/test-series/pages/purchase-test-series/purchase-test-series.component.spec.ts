import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PurchaseTestSeriesComponent } from './purchase-test-series.component';

describe('PurchaseTestSeriesComponent', () => {
  let component: PurchaseTestSeriesComponent;
  let fixture: ComponentFixture<PurchaseTestSeriesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PurchaseTestSeriesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PurchaseTestSeriesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
