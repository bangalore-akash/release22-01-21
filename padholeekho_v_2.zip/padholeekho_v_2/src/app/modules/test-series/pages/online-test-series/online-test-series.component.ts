import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/core';

@Component({
  selector: 'app-online-test-series',
  templateUrl: './online-test-series.component.html',
  styleUrls: ['./online-test-series.component.css']
})
export class OnlineTestSeriesComponent implements OnInit {

  constructor(
    private router: Router,
    private authService: AuthService,
    ) { }

  ngOnInit() {
  }
  seriesList(){
    this.authService.isSession() ? this.router.navigate(['user/test-series/SeriesList']) : this.router.navigate(['auth/test-series/SeriesList'])
  }
}
