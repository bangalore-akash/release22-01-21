import { Injectable } from '@angular/core';
import { ApiService } from 'src/app/core/services';

@Injectable({
  providedIn: 'root'
})
export class CartService {

  constructor(private apiservice: ApiService) { }

  cartListApi(data){
    return this.apiservice.get('/api/rest/cart/list', data)
  }

  movetoWishlistApi(data){
    return this.apiservice.post('/api/rest/cart/move-to-wishlist', data)
  }

  removeCartApi(data){
    return this.apiservice.post('/api/rest/cart/remove', data)
  }

  checkOutApi(data){
    return this.apiservice.post('/api/rest/booking/temporary-booking', data)
  }

  ccAvenueCheckOutApi(data){
    return this.apiservice.get('/payment/ccavenue/checkout', data)
  }
}
