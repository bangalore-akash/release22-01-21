import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { tap, finalize, catchError } from 'rxjs/operators';
import { of } from 'rxjs';
import { CourseDetailsService } from '../../services/courseDetails/course-details.service';

@Component({
  selector: 'app-course-details',
  templateUrl: './course-details.component.html',
  styleUrls: ['./course-details.component.css']
})
export class CourseDetailsComponent implements OnInit {
  isLoading: boolean = false;
  error: any;
  courseDetails: any;

  constructor(
    private ActivatedRoute: ActivatedRoute,
    private coursedetailservice: CourseDetailsService
  ) {
    this.ActivatedRoute.params.subscribe((params) => {
      if(params['id']){
        this.isLoading = true;
        this.coursedetailservice.couseDetailsApi(params['id'])
        .pipe(
          tap((response) => {
          this.courseDetails = response.data;
          }),
          finalize(() => (this.isLoading = false)),
          catchError(error => of(this.error = error)),
        ).subscribe()
      }
    })
  }

  ngOnInit() {
  }

  courseCodeDetails(){
    this.isLoading = true;

  }

}
