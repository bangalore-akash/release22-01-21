/* ......All Home Export Features....... */
export * from './pages/home/home.component';
export * from './pages/details/details.component'