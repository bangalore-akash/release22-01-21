import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-development-and-technical-integration',
  templateUrl: './development-and-technical-integration.component.html',
  styleUrls: ['./development-and-technical-integration.component.css']
})
export class DevelopmentAndTechnicalIntegrationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
