import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ZeroCostBenchmarkComponent } from './pages/zero-cost-benchmark/zero-cost-benchmark.component';
import { ImplementtionAndConsultingComponent } from './pages/implementtion-and-consulting/implementtion-and-consulting.component';
import { DevelopmentAndTechnicalIntegrationComponent } from './pages/development-and-technical-integration/development-and-technical-integration.component';
import { SupportComponent } from './pages/support/support.component';
import { StaffingSolutionsComponent } from './pages/staffing-solutions/staffing-solutions.component';

const routes: Routes = [
  {
    path: '',
    component: ZeroCostBenchmarkComponent
  } ,
  {
    path: 'ZeroCostBenchmark',
    component: ZeroCostBenchmarkComponent
  } ,
  {
    path: 'ImplementtionAndConsulting',
    component: ImplementtionAndConsultingComponent
  },
  {
    path: 'DevelopmentAndTechnicalintegration',
    component: DevelopmentAndTechnicalIntegrationComponent
  },
  {
    path: 'Support',
    component: SupportComponent
  },
  {
    path: 'StaffingSolutions',
    component: StaffingSolutionsComponent
  },
  {
    path: '',
    redirectTo: '',
    pathMatch: 'full'
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ServicesRoutingModule { }
