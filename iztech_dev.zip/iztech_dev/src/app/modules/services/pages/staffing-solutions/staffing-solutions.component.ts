import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-staffing-solutions',
  templateUrl: './staffing-solutions.component.html',
  styleUrls: ['./staffing-solutions.component.css']
})
export class StaffingSolutionsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
