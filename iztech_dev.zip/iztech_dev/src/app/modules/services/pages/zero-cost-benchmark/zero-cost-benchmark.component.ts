import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-zero-cost-benchmark',
  templateUrl: './zero-cost-benchmark.component.html',
  styleUrls: ['./zero-cost-benchmark.component.css']
})
export class ZeroCostBenchmarkComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
