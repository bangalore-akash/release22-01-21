import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-warehouse-analytics',
  templateUrl: './warehouse-analytics.component.html',
  styleUrls: ['./warehouse-analytics.component.css']
})
export class WarehouseAnalyticsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
