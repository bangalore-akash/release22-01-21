import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { OnlineTestSeriesComponent } from './pages/online-test-series/online-test-series.component';

const routes: Routes = [
  {
    path:'',
    component: OnlineTestSeriesComponent
  },
  {
    path: '',
    redirectTo: '',
    pathMatch: 'full'
  },
];

@NgModule({
  declarations: [], 
  imports: [
    CommonModule,
    RouterModule.forChild(routes)
  ],
  // exports: [RouterModule]
})
export class TestSeriesRoutingModule { }
