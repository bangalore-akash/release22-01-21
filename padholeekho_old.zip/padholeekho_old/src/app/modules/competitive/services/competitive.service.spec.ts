import { TestBed } from '@angular/core/testing';

import { CompetitiveService } from './competitive.service';

describe('CompetitiveService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CompetitiveService = TestBed.get(CompetitiveService);
    expect(service).toBeTruthy();
  });
});
