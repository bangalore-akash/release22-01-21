import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RefundComponent } from './pages/refund/refund.component';
import { RefundRoutingModule } from './refund-routing.module';

@NgModule({
  declarations: [RefundComponent],
  imports: [
    CommonModule,
    RefundRoutingModule
  ]
})
export class RefundModule { }
