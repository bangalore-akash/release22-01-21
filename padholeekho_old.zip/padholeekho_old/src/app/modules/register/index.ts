/* ......All Register Export Features....... */
export * from './pages/register/register.component'; 