import { Injectable } from '@angular/core';
import { ApiService } from 'src/app/core/services';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DetailsService {

  constructor(private apiservice: ApiService) { }

  courseCodeApi(id): Observable<any> {
    return this.apiservice.get("/api/rest/courses/listing/course-code", { id: id })
  }

  studentAlsoBroughtApi(id): Observable<any> {
    return this.apiservice.get("/api/rest/courses/listing/sab-course", { sab_course_code: id })
  }

  conceptuallyInterrelatedCoursesApi(id): Observable<any> {
    return this.apiservice.get("/api/rest/courses/listing/cic-course", { cic_course_code: id })
  }

  storetoWishlistApi(storetoWishlistParam): Observable<any> {
    return this.apiservice.post("/api/rest/wishlist/store", storetoWishlistParam)
  }

  addToCartApi(addtocartParam): Observable<any> {
    return this.apiservice.post("/api/rest/wishlist/store", addtocartParam)
  }

}
