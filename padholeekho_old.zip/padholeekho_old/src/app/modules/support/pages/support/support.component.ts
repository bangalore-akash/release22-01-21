import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SupportService } from '../../services';
import { tap, finalize, catchError } from 'rxjs/operators';
import { of } from 'rxjs';

@Component({
  selector: 'app-support',
  templateUrl: './support.component.html',
  styleUrls: ['./support.component.css']
})
export class SupportComponent implements OnInit {

  supportForm : FormGroup;
  submitted: boolean = false;
  error: any;
  isLoading: boolean = false;
  message: any;
  alertMsg: { "class": string; "text": any; "info": string; };
  dropDownList: any[];

  constructor(
    private formBuilder: FormBuilder,
    private supportservice: SupportService

  ) {
    this.supportForm = this.formBuilder.group({
      name: ["", Validators.required ],
      email: ["", [Validators.required, Validators.email]],
      super_course_id: ["", Validators.required ],
      phone: [null, [Validators.required,Validators.pattern('^((\\+91-?)|0)?[0-9]{10}$')]],
      support: ["", Validators.required ],
      via_phone: [""],
    })
   }

  get f() {
    return this.supportForm.controls;
  }

  ngOnInit() {
       // Preparation for  Dropdown
       this.supportservice.preparationDropdownApi().pipe(
        tap(response =>{
          this.dropDownList = Array.from(Object.keys(response.data), k=>response.data[k]);
        }),
        finalize(() => this.isLoading = false),
        catchError(error => of(this.error = error))
      ).subscribe()
  }

  support(){
    this.submitted = true;
    if (this.supportForm.invalid) {
      return;
    }
    var Formelement = this.supportForm.value;
    Formelement["user_id"] = localStorage.getItem('user_Id');
    this.supportservice.supportApi(Formelement).pipe(
      tap(response =>{
        this.message = response.response.message;
        if(response.status == "success" || response.status == "failure" ){
          this.alertMsg = {
            "class": 'received',
            "text": response.response.message,
            "info": 'Success',
          };
         }
      }),
      finalize(() => this.isLoading = false),
      catchError(error => of(this.error = error))
    ).subscribe()
  }

}
