import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WishlistRoutingModule } from './wishlist-routing.module';
import { WishlistComponent } from './pages/wishlist/wishlist.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { EmptyWishlistComponent } from './pages/empty-wishlist/empty-wishlist.component';

@NgModule({
  declarations: [WishlistComponent,EmptyWishlistComponent],
  imports: [
    CommonModule,
    WishlistRoutingModule,
    SharedModule
  ]
})
export class WishlistModule { }
