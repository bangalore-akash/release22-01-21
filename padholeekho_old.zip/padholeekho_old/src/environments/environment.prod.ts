export const environment = {
  production: true,
  server_url: 'https://padholeekho.com/backend/public'
};
